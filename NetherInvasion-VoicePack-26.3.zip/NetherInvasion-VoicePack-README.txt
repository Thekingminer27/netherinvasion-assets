NetherInvasion Voice Pack for Java 26.3
This is a CLIENT resource pack, NOT a Paper plugin.
Put the ZIP in %APPDATA%\.minecraft\resourcepacks to test locally.
Or host it by HTTPS and configure resource pack delivery on the server later.
The four sound keys are netherinvasion:cinematic.blaze_scout1_01, etc.
Test: /playsound netherinvasion:cinematic.blaze_scout1_01 voice @s
Enable Options > Music & Sounds > Show Subtitles if desired.
timing_sheet.csv inside this archive is developer reference, not needed for client.
